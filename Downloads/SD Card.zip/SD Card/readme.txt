===== Warning =====
Due to limited space for loading program (bootloader), which is loading application from SD Card, 
please do not change FAT file system to FAT32 or any other file system otherwise 
you will not be able to load any new program. Also, please do not resize the volume!

>> Never shift number 8 on the DIP Switch up, otherwise you will not be able to run any application until you switch it back down! <<

===== New projects =====
If you are interested in new applications, please check our website here: https://boffinmagnetic.com/community/projects

Are you experienced in programming? That's amazing! You can check our GitHub profile at https://github.com/boffinmagnetic/arduinoProjects
and modify programs, propose new ones or suggest an improvement via Issues. We always appreciate ideas from a community.

===== Custom projects =====
If you are interested in the creation of your custom FW, you can use any available number 
in range from 0 to 126 (both included) for a bin file.
The value 127 is dedicated for direct bootloading via USART from Arduino IDE or any compatible development studio.  

For development of new Arduino projects, please use Arduino IDE available from official website https://www.arduino.cc/en/software
according to your platform. To upload new project, use setting for Arduino Nano with microcontroller ATMega328p (Old bootloader)
and choose position 127 on the 8-dip switch, which is up for all of the switches except number 8.
The switches are coded in binary format according to the following schema. 

SW	Value          8-DIP switch                     Meaning
----------       _________________________________
1 |   1         |  _           _                  |
2 |   2         | |_|         |_|                 | =  1
3 |   4         |      _   _       _   _   _   _  |
4 |   8         |     |_| |_|     |_| |_| |_| |_| | =  0
5 |   16        |  1   2   3   4   5   6   7   8  | -> SW
6 |   32        |_________________________________|
7 |   64

To get a specific number, select the appropriate combination of switches and sum all values where you set the switches to 1.
Example above means, that 1 and 4 are selected (switches moved up) and value is 9 (1+8), the selected program is 009.bin in this case.

===== List of projects =====
The following list contains all projects which are uploaded into this SD Card from the factory. 

== Games ==
000.bin     = Credits
001.bin     = Platform Game with Boffin
002.bin     = Ping Pong Multiplayer
003.bin     = Tetris Game
004.bin	    = Roxy Catching Bones
005.bin     = Ping Pong Singleplayer
006.bin     = Brick Shooter
007.bin     = Space Shooter
008.bin     = Racing Game
009.bin     = Racing Game II
0010.bin    = Snake
0011.bin    = Boffin Jumping Game
0012.bin    = Math Problem Game
0013.bin    = First Press Game
0014.bin    = Octopus
0015.bin    = Tower Builder
0016.bin    = Battleship
0017.bin    = Tic-tac-toe

== Measure functions ==
032.bin		= Measure voltage
033.bin     = Low current measurement
034.bin     = Diode forward voltage measurement
035.bin     = LED forward voltage measurement
036.bin     = Light emission measurement

== Other functions ==
096.bin     = Stop watch
097.bin     = Clock with alarm
098.bin     = Contactless counter